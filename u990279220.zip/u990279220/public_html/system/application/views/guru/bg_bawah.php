<div id="tengah-footer"><img src="<?php echo base_url(); ?>system/application/views/guru/images/bg-kiri-bawah.png" /></div>
<div id="footer">
Control Panel Guru & Pegawai - Copyright &copy; SMP Negeri 2 Gabuswetan 2016<br />
Design & Maintenance by Team Unikom<a href="" target="_blank"></a>
<?php
$ip = $_SERVER['REMOTE_ADDR'];
echo" || Anda berkunjung dengan IP Address $ip";
?><br /><br /><br />
</div>
</body>
</html>
