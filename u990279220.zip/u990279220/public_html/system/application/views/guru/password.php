<div id="kiri"><h2>Selamat Datang di Control Panel Guru & Pegawai - SMA Negeri 1 Wongsorejo</h2>
<div id="isi"><br />
<form method="post" action="<?php echo base_url(); ?>index.php/guru/updatepassword">
<table width="100%" class="table" style="border:1px dashed #666666; padding:10px;">
<tr class="tr"><td class="td">Username</td><td class="td">:</td><td class="td"><input type="text" name="username" class="input" size="30" readonly="readonly" value="<?php echo $username; ?>"/> *tidak bisa diubah</td></tr>
<tr class="tr"><td class="td">Password Lama</td><td class="td">:</td><td class="td"><input type="text" name="passwordlama" class="input" size="30"/></td></tr>
<tr class="tr"><td class="td">Password Baru</td><td class="td">:</td><td class="td"><input type="text" name="password" class="input" size="30"/></td></tr>
<tr><td></td><td></td><td><input type="submit" class="submitButton" value="Ubah Password"/></td></tr>
</table>
</form>
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
</div>
</div>
