<div id="tengah">
<div id="kanan">
<a href="<?php echo base_url(); ?>index.php/guru"><div class="bg-menu">Beranda<br /><h3>Kembali ke tampilan utama</h3></div></a>
<a href="<?php echo base_url(); ?>index.php/guru/pengumuman"><div class="bg-menu">Pengumuman<br /><h3>Tulis Pengumuman</h3></div></a>
<a href="<?php echo base_url(); ?>index.php/guru/upload"><div class="bg-menu">Upload Berkas / File<br /><h3>Upload e-book, tugas, dll</h3></div></a>
<a href="<?php echo base_url(); ?>index.php/guru/absensi"><div class="bg-menu">Input Absensi<br /><h3>Masukkan rekap absensi</h3></div></a>
<a href="<?php echo base_url(); ?>index.php/guru/password"><div class="bg-menu">Ganti Password<br /><h3>Perbaharui kata sandi</h3></div></a>
<a href="<?php echo base_url(); ?>index.php"><div class="bg-menu">Website SMPN2<br /><h3>Back website SMPN 2 Gabuswetan</h3></div></a>
<a href="<?php echo base_url(); ?>index.php/web/logout"><div class="bg-menu">Log Out<br /><h3>Keluar dari Control Panel</h3></div></a>
<div id="kanan-bawah"><img src="<?php echo base_url(); ?>system/application/views/guru/images/bg-kanan-bawah.png" /></div>
</div>
</div>
