<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="<?php echo base_url(); ?>system/application/views/guru/css/dosen-style.css" rel="stylesheet" type="text/css" />
<?php echo $scriptmce; ?>
<link rel="shortcut icon" href="<?php echo base_url(); ?>system/application/views/guru/images/icon.png" />
<title>Control Panel Guru &amp; Pegawai - SMP Negeri 2 Gabuswetan</title>
</head>

<body>
<div id="tengah-header">
<div id="header"><img src="<?php echo base_url(); ?>system/application/views/guru/images/pict-logo.png" /></div>
<div id="salam"><br /><br /><br /><br />Hallo, <b><?php echo $nama; ?></b> -|- <?php echo $tanggal; ?></div>
</div>
<div id="batas-atas"><img src="<?php echo base_url(); ?>system/application/views/guru/images/bg-atas.png" /></div>
