<div id="kiri"><h2>Selamat Datang di Control Panel Guru & Pegawai - SMPN 2 Gabuswetan</h2>
<div id="isi">
<br>
Selamat datang <b><?php echo $nama; ?></b>, anda Log In dengan username <b><?php echo $username; ?></b> dan hak akses <b><?php echo $status; ?></b>
<ul>
<li class="li-class"><b>Beranda</b><br>- Tampilan utama / home screen Control Panel</li>
<li class="li-class"><b>Pengumuman</b><br>- Tulis pengumuman di situs website SMPN 2 Gabuswetan</li>
<li class="li-class"><b>Upload Berkas / File</b><br>- Upload file-file seperti e-book, materi perkuliahan, e-book, materi tugas, jadwal, dan lainnya</li>
<li class="li-class"><b>Input Absensi</b><br>- Masukkan rekap absensi harian siswa.</li>
<li class="li-class"><b>Ganti Password</b><br>- Ubah password / kata sandi yang digunakan untuk login ke Control Panel ini.</li>
<li class="li-class"><b>Log Out</b><br>- Keluar dari control panel dan akhiri session</li>
</ul>

</div>
</div>
