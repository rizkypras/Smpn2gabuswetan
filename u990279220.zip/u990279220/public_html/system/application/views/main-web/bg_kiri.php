
<div id="content">
<div id="content-kiri">

<div id="bg-judul">KEPALA SEKOLAH SMPN2 GABUSWETAN</div>
<div id="isi-side-kepsek">
<img src="<?php echo base_url(); ?>system/application/views/main-web/images/kepala-sekolah.jpg" /><br />
Drs.H. Sungeb, M.Pd
<br />NIP. 19640106 198610 1 006

</div>
<div id="bg-bawah-judul"></div>
<div id="bg-judul">LINK TERKAIT</div>
<div id="isi-side">
<ul>

<li class="li-class" ><a href="http://ppdb-smpn2gabuswetan.hol.es"  >PPDB SMPN 2 GABUSWETAN</li></a>

</ul>
</div>

<div id="bg-bawah-judul"></div>

<div id="bg-judul">ALUMNI SINEGAS 2</div>
<div id="isi-side">
<ul>
<li class="li-class">Register Alumni</li>
<li class="li-class">Daftar Alumni</li>
</ul>
</div>
<div id="bg-bawah-judul"></div>



<div id="bg-judul">KRITIK DAN SARAN</div>
<div id="isi-side">
<div id="cboxdiv" style="text-align: center; line-height: 0">
<div><iframe frameborder="0" width="215" height="245" src="http://www7.cbox.ws/box/?boxid=803848&boxtag=1vg1tq&sec=main" marginheight="0" marginwidth="0" frameborder="0" width="100%" height="100%" scrolling="auto" allowtransparency="yes" name="cboxmain7-803848" id="cboxmain7-803848"></iframe></div>
<div><iframe frameborder="0" width="215" height="75" src="http://www7.cbox.ws/box/?boxid=803848&boxtag=1vg1tq&sec=form" marginheight="0" marginwidth="0" frameborder="0" width="100%" height="100%" scrolling="no" allowtransparency="yes" name="cboxform7-803848" id="cboxform7-803848"></iframe></div>
</div>
</div>
<div id="bg-bawah-judul"></div>

</div>
