<div style="clear: both; width:100%; height: 10px;"></div>
<div id="list-bawah">
<div id="sub-list-bawah">
<div id="title-list-bawah">GALERI KEGIATAN TERBARU</div>
<div id="isi-list-bawah">
<?php
foreach($cuplikan_galeri->result_array() as $b)
{
echo "<a href='".base_url()."system/application/views/main-web/galeri/".$b['foto_besar']."'"; ?>

onclick="return hs.expand(this,
			{wrapperClassName: 'borderless floating-caption', dimmingOpacity: 0.75, align: 'center'})"
<?php
			
			echo"><div id='album-besar2'><div id='sub-album2'><img src='".base_url()."system/application/views/main-web/galeri/thumb/".$b['foto_kecil']."' border='0' width='90' title='".$b['nama_album']."'></div></div></a>";
}
?>
<ul>
<li class="li-class">Lihat koleksi foto-foto kegiatan yang lainnya. <a href="<?php echo base_url(); ?>index.php/web/data/8"><span class="submitButton2">Lihat Galeri Kegiatan</span></a></li>
</ul>
</div>
<div id="tutup-list-bawah"></div>
</div>
<div id="sub-list-bawah">
<div id="title-list-bawah">BERGABUNG DENGAN GROUP KAMI DI FACEBOOK</div>
<div id="isi-list-bawah">
<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FSmpn2Gabuswetan%2F&tabs=timeline&width=450&height=200&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="450" height="200" " scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:450px; height:200px;" allowTransparency="true"></iframe>
</div>
<div id="tutup-list-bawah"></div>
</div>
</div>
<div id="footer">
<!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = 'SgVvlBsBmL';var d=document;var w=window;function l(){
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();</script>
<!-- {/literal} END JIVOSITE CODE -->
<?php
$ip = $_SERVER['REMOTE_ADDR'];
?>
Copyright &copy; 2016 SMPN 2 GABUSWETAN. All Rights Reserved.<br />Design & Program by Team Unikom | Anda berkunjung dengan IP Address <?php echo $ip; ?></div>
</div>
</body>
</html>
