<div id="footer">
<?php
$ip = $_SERVER['REMOTE_ADDR'];
?>
Copyright &copy; 2016 SMP NEGERI 2 GABUSWETAN. All Rights Reserved.<br />Design & Program by Team Unikom | Anda berkunjung dengan IP Address <?php echo $ip; ?></div>
</div>
</body>
</html>
