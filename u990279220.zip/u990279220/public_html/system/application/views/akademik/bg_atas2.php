<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>SMA NEGERI 2 GABUSWETAN</title>
<link href="<?php echo base_url(); ?>system/application/views/akademik/css/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo base_url(); ?>system/application/views/akademik/js/dropdown.js"></script>
</head>

<body onLoad="goforit()">
<div id="luar">
<div id="head">
<div id="head-kiri"><img src="<?php echo base_url(); ?>system/application/views/main-web/images/bg-head.jpg" /></div>
<div id="head-kanan"><h6>KOLOM PENCARIAN</h6>
<form method="post" action="">
<span><input type="text" name="cari" size="25" class="input"/> <input type="submit" value="Cari" class="submitButton"/></span>
</form>
<span><h5><a href="<?php echo base_url() ?>">BERANDA</a> | LOG IN | HUBUNGI KAMI</h5></span>
</div>
</div>
<div id="menu">
<div id="sample_attach_menu_parent" class="sample_attach">PROFIL SEKOLAH</div>
<div id="sample_attach_menu_child">
<a class="sample_attach" href="">Sambutan Kepala Sekolah</a>
<a class="sample_attach" href="komputer-elektron.html">Visi dan Misi</a>
<a class="sample_attach" href="komputer-hp.html">Sasaran Mutu</a>
<a class="sample_attach" href="komputer-dell.html">Tujuan</a>
<a class="sample_attach" href="komputer-acer.html">Mottom</a>
<a class="sample_attach" href="komputer-acer.html">Sistem Pendidikan</a>
</div>
<script type="text/javascript">
at_attach("sample_attach_menu_parent", "sample_attach_menu_child", "hover", "y", "pointer");
</script>
<div id="batas-menu"><img src="<?php echo base_url(); ?>system/application/views/main-web/images/batas.jpg" /></div>

<div id="sample_attach_menu_parent2" class="sample_attach">FASILITAS SEKOLAH</div>
<div id="sample_attach_menu_child2">
<a class="sample_attach" href="komputer-lenovo.html">Sarana dan Prasarana</a>
<a class="sample_attach" href="komputer-elektron.html">Peta Lokasi Sekolah</a>
<a class="sample_attach" href="komputer-hp.html">Denah Sekolah</a>
</div>
<script type="text/javascript">
at_attach("sample_attach_menu_parent2", "sample_attach_menu_child2", "hover", "y", "pointer");
</script>
<div id="batas-menu"><img src="<?php echo base_url(); ?>system/application/views/main-web/images/batas.jpg" /></div>

<div id="sample_attach_menu_parent3" class="sample_attach">PENDIDIK & TENAGA PENDIDIK</div>
<div id="sample_attach_menu_child3">
<a class="sample_attach" href="komputer-lenovo.html">Struktur Organisasi Sekolah</a>
<a class="sample_attach" href="komputer-elektron.html">Kepala Sekolah</a>
<a class="sample_attach" href="komputer-hp.html">Komite Sekolah</a>
<a class="sample_attach" href="<?php echo base_url(); ?>index.php/web/guru">Data Guru</a>
<a class="sample_attach" href="komputer-hp.html">Data Pegawai</a>
</div>
<script type="text/javascript">
at_attach("sample_attach_menu_parent3", "sample_attach_menu_child3", "hover", "y", "pointer");
</script>
<div id="batas-menu"><img src="<?php echo base_url(); ?>system/application/views/main-web/images/batas.jpg" /></div>

<div id="sample_attach_menu_parent4" class="sample_attach">KESISWAAN</div>
<div id="sample_attach_menu_child4">
<a class="sample_attach" href="komputer-lenovo.html">Data Siswa</a>
<a class="sample_attach" href="komputer-elektron.html">Profil Osis Smanjo</a>
<a class="sample_attach" href="komputer-hp.html">Data Prestasi Siswa</a>
</div>
<script type="text/javascript">
at_attach("sample_attach_menu_parent4", "sample_attach_menu_child4", "hover", "y", "pointer");
</script>
<div id="batas-menu"><img src="<?php echo base_url(); ?>system/application/views/main-web/images/batas.jpg" /></div>

<div id="sample_attach_menu_parent5" class="sample_attach">AKADEMIK SEKOLAH</div>
<div id="sample_attach_menu_child5">
<a class="sample_attach" href="<?php echo base_url(); ?>index.php/akademik/">Absensi Harian Siswa</a>
<a class="sample_attach" href="komputer-lenovo.html">Info Penerimaan Siswa Baru</a>
</div>
<script type="text/javascript">
at_attach("sample_attach_menu_parent5", "sample_attach_menu_child5", "hover", "y", "pointer");
</script>
<div id="batas-menu"><img src="<?php echo base_url(); ?>system/application/views/main-web/images/batas.jpg" /></div>

<div id="sample_attach_menu_parent6" class="sample_attach">EKSTRA KURIKULER</div>
<div id="sample_attach_menu_child6">
<a class="sample_attach" href="komputer-lenovo.html">Bulu Tangkis</a>
<a class="sample_attach" href="komputer-elektron.html">Basket</a>
<a class="sample_attach" href="komputer-hp.html">Vokal / Paduan Suara</a>
<a class="sample_attach" href="komputer-elektron.html">Karate</a>
<a class="sample_attach" href="komputer-hp.html">Paskibraka</a>
</div>
<script type="text/javascript">
at_attach("sample_attach_menu_parent6", "sample_attach_menu_child6", "hover", "y", "pointer");
</script>

</div>
<div>
<img src="<?php echo base_url(); ?>system/application/views/main-web/images/head.jpg" />
</div>
<div id="menu">
<a href="tess"><div id="s-menu">INDEXS BERITA</div></a><div id="batas-menu"><img src="<?php echo base_url(); ?>system/application/views/main-web/images/batas.jpg" /></div>
<div id="s-menu">GELERI KEGIATAN</div><div id="batas-menu"><img src="<?php echo base_url(); ?>system/application/views/main-web/images/batas.jpg" /></div>
<div id="s-menu">PENGUMUMAN</div><div id="batas-menu"><img src="<?php echo base_url(); ?>system/application/views/main-web/images/batas.jpg" /></div>
<div id="s-menu">AGENDA SEKOLAH</div><div id="batas-menu"><img src="<?php echo base_url(); ?>system/application/views/main-web/images/batas.jpg" /></div>
<div id="s-menu">LIST DOWNLOAD</div><div id="batas-menu"><img src="<?php echo base_url(); ?>system/application/views/main-web/images/batas.jpg" /></div>
<div id="s-menu"><script language="javascript" src="<?php echo base_url(); ?>system/application/views/main-web/js/clock.js" type="text/javascript"></script><span id="clock"></span></div>
</div>
