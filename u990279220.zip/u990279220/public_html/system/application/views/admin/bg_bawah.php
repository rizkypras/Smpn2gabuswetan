<div id="menu-bawah">
<div class="copyright">
<?php
$ip = $_SERVER['REMOTE_ADDR'];
?>
<a href="<?php echo base_url(); ?>" target="_blank">SMP Negeri 2 Gabuswetan</a> &copy; 2016 - Design &  Program by<a href="http://gedelumbung.co.cc" target="_blank"> SINEGAS2</a> -||- Anda berkunjung dengan IP address <?php echo $ip; ?></div>
</div>
</body>
</html>