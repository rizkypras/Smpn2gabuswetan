<div id="isi">
<h1>Selamat Datang di Halaman Administrator Website SMP Negeri 2 Gabuswetan</h1>
Selamat datang <b><?php echo $nama; ?></b>, anda Log In dengan username <b><?php echo $username; ?></b> dan hak akses <b><?php echo $status; ?></b><br /><br />
<ul>
<li class="li-class"><b>Data Statis</b><br>- Tampilan utama / home screen Control Panel</li>
<li class="li-class"><b>Data Dinamis</b><br>- Tulis pengumuman di situs website SMP Negeri 2 Gabuswetan</li>
<ul>
<li class="li-class"><b>Indexs Berita</b><br>- Tulis pengumuman di situs website SMP Negeri 2 Gabuswetan</li>
<li class="li-class"><b>Pengumuman</b><br>- Tulis pengumuman di situs website SMP Negeri 2 Gabuswetan</li>
<li class="li-class"><b>Agenda Sekolah</b><br>- Tulis pengumuman di situs website SMP Negeri 2 Gabuswetan</li>
</ul>
</li>
<li class="li-class"><b>Sekolah</b><br>- Upload file-file seperti e-book, materi perkuliahan, e-book, materi tugas, jadwal, dan lainnya
<ul>
<li class="li-class"><b>Data Siswa-Siswi</b><br>- Tulis pengumuman di situs website SMP Negeri 2 Gabuswetan</li>
<li class="li-class"><b>Data Pegawai</b><br>- Tulis pengumuman di situs website SMP Negeri 2 Gabuswetan</li>
<li class="li-class"><b>Data Guru</b><br>- Tulis pengumuman di situs website SMP Negeri 2 Gabuswetan</li>
<li class="li-class"><b>Data Alumni</b><br>- Tulis pengumuman di situs website SMP Negeri 2 Gabuswetan</li>
<li class="li-class"><b>Data Staff Tu</b><br>- Tulis pengumuman di situs website SMP Negeri 2 Gabuswetan</li>
</ul>
</li>
<li class="li-class"><b>Modul Polling</b><br>- Masukkan rekap absensi harian siswa.</li>
<li class="li-class"><b>Modul Galeri</b><br>- Ubah password / kata sandi yang digunakan untuk login ke Control Panel ini.</li>
<li class="li-class"><b>Modul Upload</b><br>- Ubah password / kata sandi yang digunakan untuk login ke Control Panel ini.</li>
<li class="li-class"><b>Modul Absensi</b><br>- Ubah password / kata sandi yang digunakan untuk login ke Control Panel ini.</li>
<li class="li-class"><b>Hubungi Kami</b><br>- Ubah password / kata sandi yang digunakan untuk login ke Control Panel ini.</li>
<li class="li-class"><b>Log Out</b><br>- Keluar dari control panel dan akhiri session</li>
</ul>
</div>